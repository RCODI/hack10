1)Name of Application-Fresh World
2)3 key keywords- Freshness, price, proximity

3) The data sources that I've chosen are from:
a) Climate Data online - found in the Fresh World project folder under the name of "Climate_data.dat" file or https://www1.ncdc.noaa.gov/pub/data/cdo/samples/GHCND_sample_ascii.dat
b) https://catalog.data.gov/dataset/agriculture-crops-cultivated-areas-usda-in-cultivated-areas-in-indiana-in-2004-united-states-d0bfe3

4) The main idea of this project is to identify the closest location for a customer to buy his produce from using google maps and other data sources. 

5) The project has been tested on chrome and IE and seems to be working fine.

6) So far, only the basic design of the webpage is done. There is more to go.
