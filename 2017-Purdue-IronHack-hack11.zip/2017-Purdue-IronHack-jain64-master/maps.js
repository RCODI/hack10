function initMap(){
		var mapDiv = document.getElementById('map');
		var map = new google.maps.Map(mapDiv, {
			center: {lat: 40.4237, lng: -86.9212}, //This is Purdue University's Location
			zoom: 12});
		var marker = new google.maps.Marker({ 
			position: {lat: 40.4237, lng: -86.9212}, 
			label: 'Purdue University',
			map: map,
			title: 'Purdue University' 
		})
	}
