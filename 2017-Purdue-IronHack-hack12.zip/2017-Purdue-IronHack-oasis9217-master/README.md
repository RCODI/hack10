1. Name of your Application

Phase-1


2. Keywords

price, review, location


3. Description of the datasets and function design
 * [name] [link] [data type] [data columns used] [data amount] Please provide a name+link+basicInfo to each dataset you have used.

 [Local Climatological Data (LCD)][https://www.ncdc.noaa.gov/cdo-web/datasets/LCD/stations/WBAN:14835/detail]
 [Global Summary of the Day (GSOD)][https://www7.ncdc.noaa.gov/CDO/cdoselect.cmd?datasetabbv=GSOD&countryabbv=&georegionabbv=]
 [Farmers Markets Directory and Geographic Data][https://catalog.data.gov/dataset/farmers-markets-geographic-data]

 Another dataset will be added.

 * [Y] Do you use the primary dataset ”online climate data” from data.gov? 
 * [Y] [List] Are all these datasets from data.gov or data.indy.gov? If not, where are they coming from (links)?



4. Brief Description

 * Use a paragraph to introduce your project.

In this application, I would like to show the possible market places to shop lettuce based on the criteria - Price, Review, Location.

Using dataset of climate, sales of lettuce, local market places, review from web and travel information, I'd like to find the most cost efficient place to shop lettuce. Here, cost efficient would mean low price compared to reviews for the place, and price to get to the market.
Also, I can aggregate and anlyze dataset to anticipate prices as well.

The scores that I got from dataset will be displayed using D3 in form of text, pie-chart or radar chart.

The market places would be displayed as marker, which shows operation hours and ave. review score, and option for navigation.


6. Test Case
Chrome

