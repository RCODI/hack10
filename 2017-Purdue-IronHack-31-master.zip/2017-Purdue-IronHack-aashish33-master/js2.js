var market_object, market_json, text, obj;
market_object = {
  "MarketName":["West Lafayette Farmers Market","Sagamore West Farmers Market","Purdue Farmers Market","Historic Lafayette Farmers Market"],
  "Website":["http://wlfarmersmarket.com","http://www.westlafayette.in.gov/farmersmarket","http://www.purdue.edu/sustainability/initiatives/food/farmersmarket.html","http://www.lafayettefarmersmarket.com"],
  "street":["3065 N Salisbury St","Cumberland Park","Oval Dr",""],
  "Season1Date":["June to October","May to October","Jan to October","March to October"],
  "Season1Time":["Wed: 3:30 PM-7:00 PM;","Wed:3:00 PM - 6:30 PM;","Thu: 11:00 AM-3:00 PM;","Sat: 7:30 AM-12:30 PM;"],
  "x":[-86.915836,-86.9136,-86.914239,-86.891895],
  "y":[40.461469,40.4445,40.42583,40.417715],
  "Credit":["Y","N","Y","Y"],
  "Winter":["N","N","N","N"],
  "Cheese":["Y","Y","Y","Y"],
  "Eggs":["Y","N","Y","Y"],
  "Vegetables":["Y","Y","Y","Y"],
  "Jams":["Y","Y","Y","Y"],
  "Meat":["Y","Y","Y","N"],
  "Coffee":["N","N","Y","Y"],
  "Beans":["N","N","Y","N"],
  "Fruits":["Y","N","Y","Y"],
  "Grains":["N","N","Y","N"],
  "Juices":["N","N","Y","Y"],
  "WildHarvested":["N","N","Y","N"]
};
market_json = JSON.stringify(market_object);
market_object = JSON.parse(market_json);


var map;
var marks;
var market_data=[];

function initMap() {
    
    map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: 40.416702, lng: -86.875290},
        zoom: 12
    });
    

    for(var i = 0; i<4; i++){
        //latitue
        market_data.push(market_object.x[i]);
        //longitude
        market_data.push(market_object.y[i]);
    }
    
    var number_of_markets = 4
    
    var markers = [];
    