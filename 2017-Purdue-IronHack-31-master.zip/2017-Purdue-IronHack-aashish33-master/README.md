

1.Farmer's market finder
2.price,number of vendors,distance (did not intergrate the features yet)
3.Till now used: Climate Data Online (http://api.openweathermap.org/) and National Farmers Market Directory (https://www.ams.usda.gov/local-food-directories/farmersmarkets)
4.The app will show farmers maket location near lafayette,IN. It will ask the user its address, and will show how far each market it, its address, number of vendors, price and open hours ( The app is not showing these right now).
Map View:
i.Y
ii.N (not yet)
iii.N (not yet)
iv.N (not yet)
v.N( not yet)
Data Visualization(not yet)
Interaction (not yet)
5.No dependencies
6.Chrome
