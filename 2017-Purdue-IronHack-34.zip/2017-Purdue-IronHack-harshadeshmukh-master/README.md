# Welcome come to Ironhacks!

1. Name of the Application - Freshness Amplified! <br/>
2. Keywords- Distance, Mode of transportation (walk, bicycle, city bus or car), price  <br/>
3. I am yet to include the dataset to implement mashup <br/>
4. The main objective of this project is to build a website that guides the users to make a thoughtful decision over the choice market they would visit in order to buy the most fresh vegetables available in their area with the best possible deal. <br/>
5. I have just used HTML, CSS and Java script as of now.<br/>
6. I have tesed my application on the Firefox browser.<br/>

Structured Description: <br/>

Map View:<br/>
 i) Yes, I have used google API to display the basic map with center at Purdue University, West Lafayette <br/>
 ii) Yes, I have added markers for the location of markets<br/>
 iv) Yes, I have information windows to show the details of specific markets on the map. As of now I have just the market's name in the information window, however, my next immediate task is to add details to it.<br/>




